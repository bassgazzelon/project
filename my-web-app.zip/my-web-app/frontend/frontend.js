const loginForm = document.getElementById('login-form');
const message = document.getElementById('message');

loginForm.addEventListener('submit', async (event) => {
	event.preventDefault();
	const username = document.getElementById('username').value;
	const password = document.getElementById('password').value;

	try {
		const response = await fetch('http://192.168.222.149:3000/api/login', {
			method: 'POST',
			headers: { 'Content-Type': 'application/json' },
			body: JSON.stringify({ username, password }),
		});
	
		if (response.ok) {
			const data = await response.json();

			message.textContent = 'Login successful!';
			
			switch (data.role) {
				case 'nurse':
					window.location.href = 'main-dashboard.html';
					break;
				case 'doctor':
					window.location.href = 'doctor-dashboard.html';
					break;
				case 'admin':
					window.location.href = 'admin-dashboard.html';
					break;
				default:
					console.error('Invalid user role:', data.role);
					break;
			}		
		} else {
			message.textContent = 'Login failed. Please check your credentials.';
		}
	} catch (error) {
		console.error('An error occurred during login:', error);
		message.textContent = 'An error occurred during login.';
	}
});
