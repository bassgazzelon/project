const createPatientForm = document.getElementById('create-patient-form');
const message = document.getElementById('message');

createPatientForm.addEventListener('submit', async (event) => {
	event.preventDefault();
	const OHIP = document.getElementById('OHIP').value;
	const firstName = document.getElementById('firstName').value;
	const lastName = document.getElementById('lastName').value;
	const gender = document.getElementById('gender').value;
	const dateOfBirth = document.getElementById('dateOfBirth').value;
	const contactNumber = document.getElementById('contactNumber').value;
	const emergencyContactName = document.getElementById('emergencyContactName').value;
	const emergencyContactNumber = document.getElementById('emergencyContactNumber').value;
	const weight = document.getElementById('weight').value;
	const height = document.getElementById('height').value;
	const bloodType = document.getElementById('bloodType').value;
	const allergies = document.getElementById('allergies').value;
	const medicalHistory = document.getElementById('medicalHistory').value;
	const currentSymptoms = document.getElementById('currentSymptoms').value;

	try {
		const response = await fetch('http://192.168.222.149:3000/api3/create-patient', {
			method: 'POST',
			headers: { 'Content-Type': 'application/json' },
			body: JSON.stringify({
				OHIP,
				firstName,
				lastName,
				gender,
				dateOfBirth,
				contactNumber,
				emergencyContactName,
				emergencyContactNumber,
				weight,
				height,
				bloodType,
				allergies,
				medicalHistory,
				currentSymptoms
			}),
		});
		
		if (response.ok) {
			message.textContent = 'Patient record created successfully!';
		} else {
			message.textContent = 'Failed to create patient record.';
		}
	} catch (error) {
		console.error('An error occurred while creating the patient record:', error);
		message.textContent = 'An error occurred while creating the patient record.';
	}
});

