const changePasswordForm = document.getElementById('change-password-form');
const changePasswordMessage = document.getElementById('change-password-message');

changePasswordForm.addEventListener('submit', async (event) => {
	event.preventDefault();
	const username = document.getElementById('username').value;
	const oldPassword = document.getElementById('old-password').value;
	const newPassword = document.getElementById('new-password').value;
	const confirmPassword = document.getElementById('confirm-password').value;

	if (newPassword !== confirmPassword) {
		changePasswordMessage.textContent = 'Passwords do not match.';
		return;
	}

	try {
		const response = await fetch('http://192.168.222.149:3000/api2/change-password', {
			method: 'POST',
			headers: { 'Content-Type': 'application/json' },
			body: JSON.stringify({ username, oldPassword, newPassword }),
		});
		
		if (response.ok) {
			changePasswordMessage.textContent = 'Password updated successfully!';
			window.location.href = 'index.html';
		} else {
			changePasswordMessage.textContent = 'Password update failed. Please check your old password.';
		}
	} catch (error) {
		console.error('An error occurred during password update:', error);
		changePasswordMessage.textContent = 'An error occurred during password update.';
	}
});

