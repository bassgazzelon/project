const express = require("express");
const router = express.Router();
const mysql = require("mysql2/promise");

const pool = mysql.createPool({
	host: '192.168.222.151',
	user: 'group3',
	password: 'Pa$$w0rd',
	database: 'clinic_app',
});

router.get("/get-patient-record", async (req, res) => {
	const ohipNumber = req.query.ohip;

	const connection = await pool.getConnection();

	try {
		const [results] = await connection.execute("SELECT * FROM Patients WHERE OHIP = ?", [ohipNumber]);
		if (results.length > 0) {
			res.status(200).json(results[0]);
		} else {
			res.status(404).json({ error: "Patient not found" });
		}
	} catch (error) {
		console.error("An error occurred while fetching patient record:", error);
		res.status(500).json({ error: "An error occurred while fetching patient record." });
	} finally {
		connection.release();
	}
});

module.exports = router;

