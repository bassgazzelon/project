const express = require("express");
const router = express.Router();
const mysql = require("mysql2/promise");

const pool = mysql.createPool({
	host: '192.168.222.151',
	user: 'group3',
	password: 'Pa$$w0rd',
	database: 'clinic_app',
});

router.post("/save-patient", async (req, res) => {
	const { ohip, updatedData } = req.body;

	const connection = await pool.getConnection();

	try {
		const updateQuery = `
		UPDATE Patients
		SET
		FirstName = ?,
		LastName = ?,
		Gender = ?,
		DateOfBirth = ?,
		ContactNumber = ?,
		EmergencyContactName = ?,
		EmergencyContactNumber = ?,
		Weight = ?,
		Height = ?,
		BloodType = ?,
		Allergies = ?,
		MedicalHistory = ?,
		CurrentSymptoms = ?
		WHERE OHIP = ?
		`;

		const [result] = await connection.query(updateQuery, [
			updatedData.FirstName,
			updatedData.LastName,
			updatedData.Gender,
			updatedData.DateOfBirth,
			updatedData.ContactNumber,
			updatedData.EmergencyContactName,
			updatedData.EmergencyContactNumber,
			updatedData.Weight,
			updatedData.Height,
			updatedData.BloodType,
			updatedData.Allergies,
			updatedData.MedicalHistory,
			updatedData.CurrentSymptoms,
			ohip,
		]);

		if (result.affectedRows > 0) {
			res.status(200).json({ message: "Patient record updated successfully." });
		} else {
			res.status(404).json({ error: "Patient not found." });
		}
	} catch (error) {
		console.error("An error occurred while updating patient record:", error);
		res.status(500).json({ error: "An error occurred while updating patient record." });
	} finally {
		connection.release();
	}
});

module.exports = router;

